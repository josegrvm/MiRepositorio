var edadUsuario = 20;

function obtenerLicencia(){

if(edadUsuario > 18) {

    console.log(`¡Listo para obtener la licencia de conducir!`);

} else {

    console.log("Disculpa, debes esperar más años para conseguir tu licencia");

}

}
obtenerLicencia();
