

// Predicción 1: 

function miEdad() {

    console.log("Tengo: " + 25 + " años");

}
miEdad();  // Tengo 25 años



//Predicción 2: 

function miEdad(edad) {

    var edad = 25;

    console.log("Tengo: " + edad + " años");

}
miEdad();  // Tengo 25 años



// Predicción 3: 

function restar(primerNumero, segundoNumero) {

    var primerNumero = 50;
    var segundoNumero = 27;

    console.log("¡Restemos los números!");   //. ¡Restemos los números!

    console.log("primerNumero es:" + primerNumero);  // primerNumero es: 50

    console.log("segundoNumero es:" + segundoNumero); // segundoNumero es: 27

    var resultado = primerNumero - segundoNumero;

    console.log(resultado);  // 23

}
restar();   
