import React from "react";
import Formulario from "./Formulario";

function App() {
  return (
    <div>
      <Formulario />
    </div>
  );
}

export default App;